<h1 align="center"><b>✨️ Sophia 0.1 ✨️</b></h1>


# Dont Fork 
 


## Avaiilable on Telegram as [@SophiaSLBot](https://t.me/sophiaslbot)



# 🏃‍♂️ Easy Deploy 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/dihanofficial/Sophia-v1.git)



# 😍 Credits

 - [FridayUserbot](https://github.com/DevsExpo/FridayUserbot)
 - [MissJuliaRobot](https://github.com/MissJuliaRobot/MissJuliaRobot)
 - [DaisyX](https://github.com/teamdaisyx/daisy-x)
 - [ADV-Auto-Filter-Bot-V2](https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot-V2)
 - [Image-Editor](https://github.com/TroJanzHEX/Image-Editor/)
 - [WilliamButcherBot](https://github.com/thehamkercat/WilliamButcherBot)


## Special Credits

- [Daisy](https://github.com/teamdaisyx/daisy-Old)
- [TroJanzHEX](https://github.com/TroJanzHEX)
- [infotechbro](https://github.com/infotechbro/)
- [Thehamkercat](https://github.com/thehamkercat)






