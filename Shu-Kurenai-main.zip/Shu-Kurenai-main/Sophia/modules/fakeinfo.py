__mod_name__ = "💞Fake-info💞"

__help__ = """
=>> *Genarate Fake Info xD* 🤫
 ` /fakegen: Generates Fake Information
 ` /picgen: Generate a fake pic 
"""
